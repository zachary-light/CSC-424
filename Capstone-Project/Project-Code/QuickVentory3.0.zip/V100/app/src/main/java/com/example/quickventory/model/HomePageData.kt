package com.example.quickventory.model

data class HomePageData(
        val count: Int,
        val sum: String
)