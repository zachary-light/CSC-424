
<?php
    $dbh = new PDO('mysql:host=localhost;dbname=quikvory_Quik_Ventory','quikvory_qvdb','csc424');
?>